package com.regularexpression.demo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression2 {

public static void main(String[] args) {
		
		String expression = "[a-z]+";
		String input ="password";
		
		Pattern password = Pattern.compile(expression);
		Matcher confirm = password.matcher(input);
		
		while(confirm.find()) {
			System.out.println(input.substring(confirm.start(),confirm.end()));
		}
	}
}
