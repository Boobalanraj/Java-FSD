package com.annonymousinner.demo;

public interface Bike {

	public void start();
	public void stop();
}
