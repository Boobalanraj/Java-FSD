package com.annonymousinner.demo;

public class AnnonymousInnerClass {
		
		public static void main(String[] args) {
			
		Bike kawaskiNinja= new Bike() {
				public void start() {
					System.out.println("Special Implementaion of start");
				}
				public void stop() {
					System.out.println("Special implementation of stop");
				}
			};
			
			kawaskiNinja.start();
			kawaskiNinja.stop();
			
		}

	}

