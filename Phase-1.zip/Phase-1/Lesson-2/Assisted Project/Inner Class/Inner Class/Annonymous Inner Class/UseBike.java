package com.annonymousinner.demo;

public class UseBike {

	public static void main(String[] args) {
				Bike bike1= new BikeImplement();
				Bike bike2= new BikeImplement();
				
				bike1.start();
				bike2.start();
				
				bike1.stop();
				bike2.stop();;
			}

	}
