package com.array.demo;

import java.util.*;

public class MultidimensionalArray {

	public static void main(String args[])
    {
        int a[][]=new int[3][3];
        Scanner sc=new Scanner(System.in);
        int rows,columns;

        System.out.println("Enter 9 numbers");
        for(rows=0; rows<3; rows++)
        {
            for(columns=0; columns<3; columns++)
            {
                a[rows][columns]=sc.nextInt();
            }
        }

        System.out.println("\nOutput");
        for(rows=0; rows<3; rows++)			// this loop is for row
        {
            for(columns=0; columns<3; columns++)		// this loop will print 3 numbers in each row
            {
                System.out.print(a[rows][columns]+" ");
            }
            System.out.println();	// break the line after printing the numbers in a row
        }
    }
}
