package com.pillarsofoops.practice;

public abstract class ShapeAbstract {

	String color; 
    abstract double area(); 
    public abstract String toString(); 
    public ShapeAbstract(String color) 
    { 
        System.out.println("Shape constructor called"); 
        this.color = color; 
    } 
    public String getColor() 
    { 
        return color; 
    } 

}
