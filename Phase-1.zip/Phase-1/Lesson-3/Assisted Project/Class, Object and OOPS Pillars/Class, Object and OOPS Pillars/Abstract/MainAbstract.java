package com.pillarsofoops.practice;

public class MainAbstract {

    public static void main(String[] args) 
    { 
        ShapeAbstract s1 = new CircleAbstract("Red", 2.2); 
        ShapeAbstract s2 = new RectangleAbstract("Yellow", 2, 4);
        System.out.println(s1.toString()); 
        System.out.println(s2.toString()); 
    } 

}
