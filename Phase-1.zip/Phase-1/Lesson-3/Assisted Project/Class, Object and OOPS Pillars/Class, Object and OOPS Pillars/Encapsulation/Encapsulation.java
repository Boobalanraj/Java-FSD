package com.pillarsofoops.practice;

public class Encapsulation {

    private String Name; 
    private int Roll; 
    private int Age;
   
   
    public String getName()  
    { 
      return Name; 
    }
    
    public void setName(String newName) {
    	Name= newName;
    }
    
    public int getAge()  
    { 
      return Age; 
    }
    
    public void setAge(int newAge) {
    	Age = newAge;
    }
    
    public int getRoll()  
    { 
       return Roll; 
    }
    
    public void setRoll(int newRoll) {
    	Roll=newRoll;
    }

}
