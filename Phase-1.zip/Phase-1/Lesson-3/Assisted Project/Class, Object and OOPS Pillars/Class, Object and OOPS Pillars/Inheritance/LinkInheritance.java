package com.pillarsofoops.practice;

public class LinkInheritance extends Inheritance  {

    public int seatHeight; 
    public LinkInheritance(int gear,int speed,int startHeight) 
    {  
        super(gear, speed); 
        seatHeight = startHeight; 
    }  
    public void setHeight(int newValue) 
    { 
        seatHeight = newValue; 
    } 
    @Override
    public String toString() 
    { 
        return (super.toString()+ 
                "\nseat height is "+seatHeight); 
    } 

    public static void main(String args[])  
    { 
    	LinkInheritance mb = new LinkInheritance(3, 100, 25); 
        System.out.println(mb.toString());
    } 

}
