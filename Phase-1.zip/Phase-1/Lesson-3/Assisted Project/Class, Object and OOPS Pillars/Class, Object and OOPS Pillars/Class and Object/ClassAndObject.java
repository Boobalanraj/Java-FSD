package com.pillarsofoops.practice;

public class ClassAndObject {
	
	String name;
	String college;
	int rollno;
	String department;
	
	public ClassAndObject(String name, String college, int rollno, String department) {
        this.name = name; 
        this.college = college; 
        this.rollno = rollno; 
        this.department = department; 
	}
    public String getName() 
    { 
        return name; 
    } 
    public String getCollege() 
    { 
        return college; 
    } 
    public int getRollno() 
    { 
        return rollno; 
    } 
    public String getDeparment() 
    { 
        return department; 
    }
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return("Hi My name is "+this.getName()+"\nMy college is "+this.getCollege()+"\nMy Roll NO is "+this.getRollno()+" and Department is "+this.getDeparment());
		
	} 
	public static void main(String[] args) {
		ClassAndObject person = new ClassAndObject("Kumar","ABCD College",31001,"CSE");
		System.out.println(person.toString());
	}

	
}
