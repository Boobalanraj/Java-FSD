package com.keywords.practice;

public class Throws {

	void division()throws ArithmeticException{
		int a= 10,b=0,result;
		result=a/b;
		System.out.println("The result is: "+result);
	}
	public static void main(String[] args) {
		Throws error= new Throws();
		try {
			error.division();
		}
		catch(ArithmeticException message) {
			
			System.out.println("error: "+message);
		}
		System.out.println("End of Program");
	}
}
