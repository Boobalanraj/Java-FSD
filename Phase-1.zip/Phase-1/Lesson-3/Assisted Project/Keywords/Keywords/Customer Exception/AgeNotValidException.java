package com.keywords.practice;

public class AgeNotValidException extends Exception {

	private String msg;

	public AgeNotValidException(String msg) {

		this.msg = msg;
	}

	@Override
	public String toString() {
		return "AgeNotValidException [error:" + msg + "]";
	}
	
	
}
