package com.filehandling.practice;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class CreateFile {
	
	public static void createFile()throws IOException{
		File create = new File("E:\\file\\textfile.txt");
		
		if(create.createNewFile()) {
			System.out.println("File is created");
		}
		else {
			System.out.println("File is already created");
		}
		
		FileWriter write = new FileWriter(create);
		write.write("Welcome to File Handling");
		write.close();
	}
	
	public static void createFileUsingOutputStream()throws IOException{
		FileOutputStream out = new FileOutputStream("E:\\file\\fileoutput.txt");
		
		String input ="Welcome you got Output";
		byte array[]= input.getBytes();
		out.write(array);
		System.out.println("Data Written Successfully");
		out.close();
	}
	
	public static void createFileUsingNIO() throws IOException
	{
		
		Path path=Paths.get("E:\\file\\testfileNIO.txt");
		//write data using file class
		String input="Welcome  to NIO";
		byte array[]=input.getBytes();
		
		Files.write(path, array, StandardOpenOption.CREATE,StandardOpenOption.APPEND);
		System.out.println("Data Written Successfully");
		
		
		//if you want to write data of list to  files directly
		Path path1=Paths.get("E:\\file\\testfileNIO1.txt");
		//write data  using Files class
		
		List<String> list=Arrays.asList("This  is my first line","This is my secondLine");
		Files.write(path1, list, StandardOpenOption.CREATE,StandardOpenOption.APPEND);
		System.out.println("Lines Written Successfully");
		
	}

	public static void main(String[] args) {
		try {
			createFile();
			createFileUsingOutputStream();
			createFileUsingNIO();
		}
		catch(IOException message) {
			message.printStackTrace();
		}
	}
}
