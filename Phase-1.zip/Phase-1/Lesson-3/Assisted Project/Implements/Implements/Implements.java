package com.implement.practice;

public class Implements extends Exception{

	String impl;
	Implements(String impl2){
		impl=impl2;
	}
	public String toString() {
		return("Error: "+impl);
	}
	
	public static void main(String[] args) {
		try {
			System.out.println("Starting of try block");
			
			throw new Implements("This is my error message ");
		}
		catch(Exception message) {
			System.out.println("catch block");
			System.out.println(message);
		}
	}
}
