package com.diamondproblem.practice;

public class DiamondProblem implements First,Second{

	public void show() {
		First.super.show();
		Second.super.show();
	}
	public static void main(String[] args) {
		DiamondProblem display = new DiamondProblem();
		display.show();
	}
}
