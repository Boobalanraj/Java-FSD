package com.synchronize.practice;

public class User{


	public static void main(String[] args) {
		
		Sender sender = new  Sender();
		
		Synchronized t1= new Synchronized("Raj", "What are you doing?", sender);
		Synchronized t2= new Synchronized("kumar","Reading book,What about you?",sender);
	
		t1.start();
		t2.start();
	}
}
