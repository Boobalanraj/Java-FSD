package com.orderstatistics.demo;

import java.util.Arrays;

public class SmallestElementExample {

	public static int SmallestElementExample(Integer array[],int n){
		Arrays.sort(array);
		
		return array[n-1];
	}
	
	public static void main(String[] args) {
		Integer array[]= new Integer[] {12, 3, 5, 7, 19};
		
		int n=2;
		
		System.out.println( n+" Smallest element is "+SmallestElementExample(array,n) );
	}
}
