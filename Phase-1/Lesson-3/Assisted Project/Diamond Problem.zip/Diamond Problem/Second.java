package com.diamondproblem.practice;

public interface Second {

    default void show() 
    { 
        System.out.println("Default Second"); 
    } 

}
