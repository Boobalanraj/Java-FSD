package com.keywords.practice;

public class Finally {

	public static void main(String[] args) {
		int a= 45,b=0,result=0;
		try {
			result=a/b;
		}
		catch(ArithmeticException message) {
			System.out.println("Error: "+message);
		}
		finally {
			System.out.println("The result is: "+result);
		}
	}
}
