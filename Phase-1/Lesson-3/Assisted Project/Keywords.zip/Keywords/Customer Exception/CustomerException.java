package com.keywords.practice;

public class CustomerException {

	static void check(int age)throws AgeNotValidException{
		if (age<18)
			throw new AgeNotValidException("user can not vote");
		else
			System.out.println("use can vote");
	}
	
	public static void main(String[] args) {
		
		try {
			check(16);
		}
		catch(AgeNotValidException message) {
			System.out.println("error: "+message);
		}
	}
}
