package com.thread.practice;

public class RunnableThread implements Runnable{
	private static int count =0;
    public RunnableThread(){
        
    }
    public void run() {
        while(RunnableThread.count <= 10){
            try{
                System.out.println("expection Thread: "+(++RunnableThread.count));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: "+iex.getMessage());
            }
        }
    } 

	public static void main(String[] args) {

    System.out.println("Starting Thread...");
    RunnableThread thread = new RunnableThread();
    Thread error = new Thread(thread);
    error.start();
    while(RunnableThread.count <= 10){
        try{
            System.out.println("main Thread: "+(++RunnableThread.count));
            Thread.sleep(100);
        	} 
        catch (InterruptedException iex){
            System.out.println("Exception in main thread: "+iex.getMessage());
        	}
    	}
    System.out.println("End of Main Thread...");
	}
}
