package com.trycatch.practice;

public class TryCatch {

	public static void main(String[] args) {
		int [] array = new int[6];
		
		try {
			array[7]=10;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array Index is out Bounds");
		}
		finally {
			System.out.println("The array is of size " + array.length);
		}
	}
}
