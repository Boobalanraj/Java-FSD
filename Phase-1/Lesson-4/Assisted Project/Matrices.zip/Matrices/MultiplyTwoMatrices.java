package com.matrices.demo;

public class MultiplyTwoMatrices {

	public static void main(String[] args) {
		int r1= 3,c1=2;
		int r2=2,c2=3;
		
		int [][] firstMatrix = {{2,9},{-10,15},{2,-4}};
		int [][] secondMatrix = {{4,6,7},{10,11,15}};
		
		int product[][]= multiplyMatrix(firstMatrix,secondMatrix,r1,c1,c2);
		
		display(product);
	}

	private static int[][] multiplyMatrix(int[][] firstMatrix, int[][] secondMatrix, int r1, int c1, int c2) {
		// TODO Auto-generated method stub
		int product[][] = new int[r1][c2];
		
		for(int i= 0;i<r1;i++) {
			
			for(int j =0;j<c2;j++) {
			
				for(int k =0;k<c1;k++) {
					product[i][j]= firstMatrix[i][k]*secondMatrix[k][j];
					
				}
			}
		}
		return product;
	}
	public static void display(int product[][]) {
		System.out.println("Product of two Matrix: ");
		for(int row[]:product) {
			for(int column: row) {
				System.out.print(column+" ");
			}
			System.out.println();
		}
	}
}
