package com.queue.demo;

import java.util.Queue;

import java.util.*;

public class QueueDemo {

	public static void main(String[] args) {
		Queue<String> fifo= new LinkedList<String>();
		
		fifo.add("Raj");
		fifo.add("Kumar");
		fifo.add("Bala");
		fifo.add("Naruto");
		fifo.add("Alex");
		fifo.add("Chandru");
		
		System.out.println("Queue is : "+fifo);
		
		
		//find head of queue
		System.out.println("Head of Queue: "+fifo.peek());
		
		fifo.remove();
		
		System.out.println("After Removing Head: "+fifo);
		
	}
}
