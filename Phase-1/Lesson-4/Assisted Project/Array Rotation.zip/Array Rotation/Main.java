package com.arrayrotation.demo;

public class Main {

	public static void main(String[] args) {
		ArrayRotation rotate = new ArrayRotation();  
		
		int array[]= {1,2,3,4,5,6,7};
		rotate.rotation(array, 12);
		
		for(int i=0;i<array.length;i++) {
			System.out.print(array[i]+" ");
		}
	}
}
