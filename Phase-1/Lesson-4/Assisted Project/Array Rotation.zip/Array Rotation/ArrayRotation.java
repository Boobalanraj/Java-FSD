package com.arrayrotation.demo;

public class ArrayRotation {

	public void rotation(int num[],int n) {
			
			if(n> num.length) {
				
				n= n% num.length;  //10 divide by 7  will give reminder as 3
				
				int result[] = new int[num.length];//create new array with size of given array
				
				
				for(int i=0; i<n; i++) {
					
					result[i]= num[num.length-n+i]; // 7-3= 4 this will  skip 4 elements (3rd index) and rest elements  will be rotated
					
				}
				
				int j=0;
				
				for(int i=n; i<num.length;i++) {
					
					result[i]=num[j];
					j++;
				}
				
				System.arraycopy(result, 0, num, 0, num.length);
				
			}			
	}
}
