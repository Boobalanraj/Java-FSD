package com.doublelinkedlist.demo;

public class DoubleLinkedList {

	Node head;//first node
	
	//inner class
	class Node{
		int data;
		Node next;
		Node prev;
		
		Node(int d){
			data= d;
		}
	}
	
	public void push(int new_data) {
		Node new_node = new Node(new_data);
		new_node.next = head;
		new_node.prev = null;
		if (head != null) {
			head.prev= new_node;
		head = new_node;
		}
	}
		
		public void InsertAfter(Node prev_Node,int new_data) {
			if(prev_Node == null) {
				System.out.println("The given previous node cannot be null ");
				return;
			}
			Node new_node = new Node(new_data);
			new_node.next = prev_Node.next;
			prev_Node.next= new_node;
			new_node.prev=prev_Node;
			
			if(new_node.next !=null)
				new_node.next.prev= new_node;

		}
		
			void append(int new_data) {
				Node new_node = new Node(new_data);
				new_node.next = null;
				
				Node last =head;
				
				if(head == null) {
					new_node.prev = null;
					head = new_node;
					return;
				}
				
				while(last.next != null) 
					last = last.next;
					last.next = new_node;
					new_node.prev = last;
			}
			
			public void printlist(Node node) {
				Node last = null;
				System.out.print("Traversal in forward Direction: ");
				while(node != null) {
					System.out.print(node.data+ " ");
					last = node;
					node = node.next;
				}
				System.out.println();
				System.out.print("Traversal in reverse Direction: ");
				while(last != null) {
					System.out.print(last.data+" ");
					last = last.prev;
				}
			}
			public static void main(String[] args) {
				
				DoubleLinkedList dll =  new DoubleLinkedList();
			
				dll.append(48);
				
				dll.push(5);
				dll.push(6);
				dll.push(4);
				
				dll.append(3);
				dll.InsertAfter(dll.head.next,8);
				
				System.out.println("Create DLL is: ");

				dll.printlist(dll.head);
			}
	}