package com.sortandsearch.demo;

public class BubbleSort {

	public static void main(String[] args) {

		int[] array = { 5,1,4,2,8 };
		
		bubbleSort(array);
		System.out.print("The Bubble sort: ");
		for (int i = 0; i < array.length; i++) {

			System.out.print(array[i]+" \t");
		}
	}

	public static void bubbleSort(int[] array) {
		int length = array.length;
		int temp = 0;
		for (int i = 0; i < length; i++) {
			
			for (int j = 1; j < (length); j++) {
				
				if (array[j - 1] > array[j]) {
					temp = array[j - 1];
					array[j - 1] = array[j];
					array[j] = temp;
					
					for(int x:array) {
						System.out.print( x+" ");}
					System.out.println("\n");
				}
				
			}
			
		}

	}

}
