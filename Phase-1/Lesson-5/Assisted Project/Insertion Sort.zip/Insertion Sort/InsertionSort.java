package com.sortandsearch.demo;

public class InsertionSort {

	public static  void main(String[] args){
        
   	int[] array = {12,11, 13, 5 ,6};
   	
       insertionSort(array);
       
       System.out.print("The Insertion Sortibng: ");
       for(int i=0;i<array.length;i++){

           System.out.print(array[i]+" \t");

       }
    }
   public static void insertionSort(int[] array){

	    int length = array.length;
	    
	    for(int j=1;j<length;j++){
	    	
	    	int key = array[j];
	    	int i=j-1;
	    	
	    while ((i>-1) && (array[i]>key)){
	
	        array[i+1]=array[i];
	        i--;
	       
	    }
	    array[i+1]=key;
	         }
   }
}
