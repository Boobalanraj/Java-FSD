package com.sortandsearch.demo;

import java.util.Arrays;

public class ExponentialSearch {

	public static void main(String[] args) {
		int array[] = {6,12,18,24,32};
		int value=24;
		int outcome=exponentialSearch(array,array.length,value);
		
		if(outcome<0) {
			System.out.println("Element is not present in array");
		}
		else {
			System.out.println("Element found at index: "+outcome+", Key is: "+array[outcome]);
		}
	}

	private static int exponentialSearch(int[] arr, int length, int value) {
		// TODO Auto-generated method stub
		
		//check if the element is available at  first index
		if(arr[0]==value) {
			return 0;
		}
		
		int i=1; //find out the range by repeated doubling
		
		while(i<length && arr[i]<=value) {
			i= i*2;
		}
		
		//call binary search
		
		
		return Arrays.binarySearch(arr,i/2,Math.min(i, length),value);
	}
}
