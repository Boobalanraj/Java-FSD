package com.sortandsearch.demo;

import java.util.Scanner;

public class LinearSearch {


	public static void main(String[] args) {
		
		int  [] array= {17,2,30,50,32,40};
		
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the Element to  be Searched: ");
		
		int Value= sc.nextInt();
		
		int result= linearing(array,Value);
		
		if(result==-1) {
			System.out.println("Element Not Found In The Array");
		}
		else {
			System.out.println("Element Found at index: ["+result+"] , and Search  key is :"+array[result]);
		}
		sc.close();
	}
	
	private static int linearing(int[] array,int Value) {
		
		 		
		for(int i=0; i<array.length; i++) {
			
			if(array[i]==Value) {
				return i;
			}
			
		}
		return -1;
	}
}
