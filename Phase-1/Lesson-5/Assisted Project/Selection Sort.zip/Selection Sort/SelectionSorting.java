package com.sortandsearch.demo;

public class SelectionSorting {


    public static void main(String[] args) {

    
    int[] array = {30,43,1,15,20};
    
    selectionSort(array);
    
    System.out.print("The sorted elements are: ");
    
    for(int i:array){

        System.out.print(i +"\t");
         }
     }

    public static void selectionSort(int[] array){

    	  int length = array.length;
    	
        for(int i=0;i<length-1;i++){

            int index =i;//beggining of array
            
            for(int j=i+1;j<length;j++){
            	
                if(array[j]<array[index]){

                    index =j; //smallest index
                }

            }
            int smallNumber = array[index];
            array[index]= array[i];
            array[i]= smallNumber;
            
            for(int x:array){
            	System.out.print(x+",");   
            } System.out.println("\n"); 

    }
}
}
