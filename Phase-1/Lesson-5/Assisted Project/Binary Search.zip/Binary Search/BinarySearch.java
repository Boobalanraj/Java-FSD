package com.sortandsearch.demo;

public class BinarySearch {


	public static void main(String[] args) {
		int array[] = {3,6,9,12,15};
		
		int key=9;
		
		int arrayLength=array.length;
		
		try {
			binarySearch(array,0,key,arrayLength);
		} catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println("Error: "+e);
		}
		
	}

	private static void binarySearch(int[] array, int lowerbinary, int key, int higherbinary) {
		
		int midValue= (lowerbinary+higherbinary)/2;
		
		while(lowerbinary<=higherbinary) {
			
			if(array[midValue]<key)
			{
				lowerbinary= midValue+1;
			}
			else if(array[midValue]==key)
			{
				System.out.println("Element found at index: "+midValue);
				break;
			}
			else {
				higherbinary=midValue-1;
			}
			midValue=(lowerbinary+higherbinary)/2;
		}
		if(lowerbinary>higherbinary) {
			System.out.println("Element Not Found");
		}
		
	}
}
