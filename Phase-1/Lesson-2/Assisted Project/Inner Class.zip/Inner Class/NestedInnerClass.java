package com.innerclass.demo;

//class--->Inner Class--->call declare private method--->create object in main class
//main class--->create object for inner class--->call the method in a Inner class using declare object name for Inner class


public class NestedInnerClass {

	String msg ="Hello Java";
	int n =10;
	
	class Inner{
		void display() {
			System.out.println("welcome Home");
			System.out.println(msg);
			System.out.println(n);
		}
	}
	
	public static void main(String[] args) {
		NestedInnerClass obj = new NestedInnerClass();
		NestedInnerClass.Inner in = obj.new Inner();
		in.display();
	}
}
