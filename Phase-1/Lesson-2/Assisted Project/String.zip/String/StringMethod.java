package com.string.demo;

public class StringMethod {

	public static void main(String[] args) {
		String s1 = new String("Learning Java");
		
		System.out.println("length of string: "+s1.length());
		
		System.out.println("change to UPPER CASE: "+s1.toUpperCase());
		System.out.println("change to lower case: "+s1.toLowerCase());
		System.out.println("check the contains: "+s1.contains("Java"));
		System.out.println("SubString between 6 to 10 characters: "+s1.substring(9,13));
		 
		 String result[]= s1.split(" ");
		 
		 for(String s: result) {
			 System.out.println(s);
		 }
		 
		 //comparison
		 
		 String s2= "learning java";
		 //case of equal
		 if(s1.equals(s2)) {
			 System.out.println("Validated");
		 }
		 else {
			 System.out.println("Not Valid");
		 }
		 //case of equal ignorecase
		 if(s1.equalsIgnoreCase(s2)) {
			 System.out.println("Validated");
		 }
		 else {
			 System.out.println("Not Valid");
		 }
		 //comparison using ==
		 if(s1==s2) {
			 System.out.println("Validated");
		 }
		 else {
			 System.out.println("Not Valid");
		 }
	}
}
