package com.string.demo;

public class StringBuilderPractice {

	public static void main(String[] args) {
		String s1 = new String("Hello World");
		
		StringBuilder str = new StringBuilder(s1);
		System.out.println("Length of StringBuilder: "+str.length());
		
		str.append("Program");
		System.out.println(str);
		
		str.insert(11," ");
		System.out.println(str);
		
		str.replace(12,19,"Java");
		System.out.println(str);
		
		str.reverse();
		System.out.println(str);
	}
}
