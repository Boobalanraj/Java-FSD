package com.regularexpression.demo;

import java.util.regex.*;

public class RegularExpression1 {

	public static void main(String[] args) {
		
		String expression = "[a-z]+";
		String input ="password";
		
		Pattern password = Pattern.compile(expression);
		Matcher confirm = password.matcher(input);
		
		if(confirm.matches()) {
			System.out.println("Password Valid");
		}
		else {
			System.out.println("Invalid Password");
		}
	}
}
