import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive2',
  templateUrl: './directive2.component.html',
  styleUrls: ['./directive2.component.css']
})
export class Directive2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
