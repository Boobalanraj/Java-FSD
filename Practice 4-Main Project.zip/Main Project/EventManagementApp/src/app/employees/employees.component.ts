import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { CrudHttpService } from '../crud-http.service';
import { UserClass } from '../UserClass';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  formValue ! : FormGroup;
  UserClassModelObject : UserClass = new UserClass();
  employeedetails ! : any;
  showAdd !: boolean;
  showUpdate !:boolean;
  showReset ! :boolean;

  constructor(private builder:FormBuilder, private api:CrudHttpService,private router:Router) { }

  ngOnInit(): void {
    this.formValue = this.builder.group({
      id:[''],
      firstname : [''],
      lastname : [''],
      email:[''],
    })
    this.getAllEmployee();
  }

  showAddEmployee(){
    this.formValue.reset();
    this.showAdd=true;
    this.showUpdate=false;
    this.showReset=false;
  }

  AddEmployeeDetails(){
    this.UserClassModelObject.id = this.formValue.value.id;
    this.UserClassModelObject.first_name = this.formValue.value.firstname;
    this.UserClassModelObject.last_name = this.formValue.value.lastname;
    this.UserClassModelObject.email = this.formValue.value.email;

    this.api.postEmployee(this.UserClassModelObject).subscribe(res=>{
      alert("Employee Added SuccessFully");
      this.formValue.reset();
      let ref =document.getElementById('close')
      ref?.click();
      this.getAllEmployee();
    },
    err=>{
      alert("Employee Not Added");
    })
  }

  getAllEmployee(){
    this.api.getEmployee().subscribe(res=>{
      this.employeedetails = res;
    })
  }

  deleteEmployee(employee : any){
    this.api.deleteEmployee(employee.id).subscribe(res=>{
      alert("Employee Deleted");
      this.getAllEmployee();
    })
  }

  updateEmployee(employee : any){
    this.showAdd=false;
    this.showUpdate=true;
    this.showReset=false;
    this.UserClassModelObject.id =employee.id;
    this.formValue.controls['id'].setValue(employee.id);
    this.formValue.controls['firstname'].setValue(employee.first_name);
    this.formValue.controls['lastname'].setValue(employee.last_name);
    this.formValue.controls['email'].setValue(employee.email);

  }
  saveEmployeeDetails(){
    this.UserClassModelObject.id = this.formValue.value.id;
    this.UserClassModelObject.first_name = this.formValue.value.firstname;
    this.UserClassModelObject.last_name = this.formValue.value.lastname;
    this.UserClassModelObject.email = this.formValue.value.email;

    this.api.updateEmployee(this.UserClassModelObject,this.UserClassModelObject.id).subscribe(res=>{
      alert("Updated Successfully");
      this.formValue.reset();
      let ref =document.getElementById('close')
      ref?.click();
      this.getAllEmployee();
    })
  }

  logout(){
    alert("Admin Logout Successfully");
    this.router.navigate(['']);
  }

  resetpassword(){
    this.showReset=true;
  }

  changePassword(){
    alert("Change Password Successfully");
    this.formValue.reset();   
    let ref =document.getElementById('end')
    ref?.click();
  }

}
