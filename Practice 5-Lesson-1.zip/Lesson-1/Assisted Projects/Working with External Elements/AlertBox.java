package com.practice.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","F:\\\\Java FSD Software\\\\chrome\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://nxtgenaiacademy.com/alertandpopup/");
		
		//Alert box
		driver.findElement(By.name("alertbox")).click();
		System.out.println("alertbox");
		driver.switchTo().alert().accept();
	
//		confirm Alert box
		driver.findElement(By.name("confirmalertbox")).click();
		driver.switchTo().alert().accept();
		System.out.println("confirm alert box");
		System.out.println("text: "+driver.findElement(By.id("demo")).getText());
		
//		prompt alert box
		driver.findElement(By.name("promptalertbox1234")).click();
		driver.switchTo().alert().sendKeys("yes");
		driver.switchTo().alert().accept();
		System.out.println("prompt alert box");
		System.out.println("text: "+driver.findElement(By.id("demoone")).getText());
		
		driver.close();
	}

}
