package com.practice.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","F:\\\\Java FSD Software\\\\chrome\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.shine.com/registration/");
		
		WebElement checkbox = driver.findElement(By.id("id_privacy"));
		if(checkbox.isSelected())
		{
			System.out.println("Check box is selected");
			System.out.println("status:"+checkbox.isSelected());
		}
		else {
			System.out.println("Check is not selected");
		}
		
		checkbox.click();
		System.out.println("status: "+checkbox.isSelected());
		System.out.println("check box is unselectd");
		
		driver.close();

	}

}
