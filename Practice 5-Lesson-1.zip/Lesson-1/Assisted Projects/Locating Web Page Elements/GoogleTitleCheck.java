package com.selenium.practicee;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleTitleCheck {

	public static void main(String[] args) {
		
		String path= "F:\\Java FSD Software\\chrome\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",path);
		
		WebDriver driver = new ChromeDriver();
		
		String url="http://www.google.com";
		driver.get(url);
		
		System.out.println("Title"+driver.getTitle());
		
		assertEquals("Google",driver.getTitle());
		
		driver.close();
	}

}
