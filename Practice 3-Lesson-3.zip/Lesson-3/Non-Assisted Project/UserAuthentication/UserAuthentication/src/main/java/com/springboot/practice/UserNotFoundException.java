package com.springboot.practice;

public class UserNotFoundException extends RuntimeException {

}
