package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import com.spring.dao.ProductDao;
import com.spring.entity.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDao dao;

	@GetMapping("/listproduct")
	public String getAllProducts(ModelMap map) {

		List<Product> list = dao.getAllProducts();
		map.addAttribute("list", list);
		return "productsdetails";

	}
}
