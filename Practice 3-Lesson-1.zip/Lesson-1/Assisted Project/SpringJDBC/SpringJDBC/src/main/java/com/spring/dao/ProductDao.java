package com.spring.dao;

import java.sql.ResultSet; 	
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.spring.entity.Product;

@Repository
public class ProductDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<Product> getAllProducts() {

		return jdbcTemplate.query("select * from products", new RowMapper<Product>() {

			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

				Product object = new Product();
				object.setId(rs.getInt(1));
				object.setName(rs.getString(2));
				object.setPrice(rs.getBigDecimal(3));
				object.setDateAdded(rs.getTimestamp(4));
				return object;

			}
		});
	}
}
