package com.simplilearn.demo;

public class HelloWorld {
	public void print() {
		System.out.println("Welcome to Spring Framework");
	}
}
